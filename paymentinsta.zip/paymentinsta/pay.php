<?php 
$product_name = $_GET["product_name"];
$price = $_GET["price"];
$name = $_GET["name"];
$phone = $_GET["phone"];
$email = $_GET["email"];


include 'src/instamojo.php';

$api = new Instamojo\Instamojo('test_bf1ca89df9196295e3e0875230a', 'test_dfc66a14243a9b4bad6a86c0c6a','https://test.instamojo.com/api/1.1/');


try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => $product_name,
        "amount" => $price,
        "buyer_name" => $name,
        "phone" => $phone,
        "send_email" => true,
        "send_sms" => true,
        "email" => $email,
        'allow_repeated_payments' => false,
        "redirect_url" => "http://boliarweb.000webhostapp.com/paymentinsta/thankyou.php",
        "webhook" => "http://boliarweb.000webhostapp.com/paymentinsta/webhook.php"
        ));
    //print_r($response);

    $pay_ulr = $response['longurl'];
    
    //Redirect($response['longurl'],302); //Go to Payment page

    header("Location: $pay_ulr");
    exit();

}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}     
  ?>